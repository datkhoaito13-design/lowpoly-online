const { WebSocketServer } = require('ws');
const wss = new WebSocketServer({ port: process.env.PORT || 8080 });
let q = [];
const send = (w, o) => w.readyState === 1 && w.send(JSON.stringify(o));
setInterval(() => {
  const now = Date.now(); q = q.filter(e => e.ws.readyState === 1); q.sort((a, b) => a.rk - b.rk);
  for (let i = 0; i + 1 < q.length; i++) {
    const a = q[i], b = q[i + 1], win = 100 + Math.max(now - a.t, now - b.t) / 1000 * 15; // +15 điểm cho mỗi giây chờ
    if (Math.abs(a.rk - b.rk) <= win) { q.splice(i, 2); a.ws.peerGuest = b.ws; send(a.ws, { t: 'host' }); i--; }
  }
}, 1000);
wss.on('connection', (ws) => {
  ws.on('message', (raw) => {
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (m.t === 'queue') {
      q = q.filter(e => e.ws !== ws);
      q.push({ ws, rk: Math.max(0, Math.min(4000, Number(m.rk) || 1000)), t: Date.now() }); send(ws, { t: 'wait' });
    } else if (m.t === 'code' && ws.peerGuest && /^[A-Z0-9]{4}$/.test(m.code)) {
      setTimeout(() => send(ws.peerGuest, { t: 'join', code: m.code }), 1500); // chờ host đăng ký PeerJS
    }
  });
  ws.on('close', () => { q = q.filter(e => e.ws !== ws); });
});
console.log('Matchmaker listening');
